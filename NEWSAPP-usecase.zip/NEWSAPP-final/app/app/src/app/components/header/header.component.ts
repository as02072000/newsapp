import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { NewsService } from 'src/app/service/news.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnChanges{

  f : FormGroup;

  topic : string = ''

  constructor(private newsService : NewsService, private router : Router, private fb: FormBuilder){
    this.f = this.fb.group({
      topic : ['',Validators.required]
    });
  }

  getLoginStatus(){
    return this.newsService.getLoginStatus();
  }

  logout(){
    sessionStorage.removeItem('loginStatus')
    sessionStorage.removeItem('token')
    this.router.navigate([''])
  }

  setNewsTopic(){
    this.newsService.setTopic(this.topic)
    this.topic = ''
    this.router.navigate(['/articles'])
  }

  // getNewsForTheTopic(){
  //   console.log('topic -> ' + this.topic)
  //   this.newsService.getNewsArticles(this.topic).subscribe(
  //     (res)=>{
  //       console.log('getNewsArticles -> ',res)
  //     },
  //     (error) => {
  //       console.log('getNewsArticles -> ',error)
  //     }
  //   )
  // }

  ngOnChanges(changes: SimpleChanges): void {
      // for(const propname)
  }
}
