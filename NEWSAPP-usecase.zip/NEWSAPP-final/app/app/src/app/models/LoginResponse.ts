export interface LoginResponse{
    response : {
        message : string,
        token : string
    } 
}