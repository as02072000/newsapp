package com.newsapp.authenticationserver.service;

public interface UserService {
    boolean validateUserService(String userName, String password);
}
