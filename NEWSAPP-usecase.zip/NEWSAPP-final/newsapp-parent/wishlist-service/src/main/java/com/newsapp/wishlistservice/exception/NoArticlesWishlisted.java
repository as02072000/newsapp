package com.newsapp.wishlistservice.exception;

public class NoArticlesWishlisted extends Throwable {
    public NoArticlesWishlisted(String s) {
        super(s);
    }
}
