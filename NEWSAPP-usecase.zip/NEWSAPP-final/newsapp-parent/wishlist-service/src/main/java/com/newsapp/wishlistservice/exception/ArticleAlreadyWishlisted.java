package com.newsapp.wishlistservice.exception;

public class ArticleAlreadyWishlisted extends Throwable {
    public ArticleAlreadyWishlisted(String s) {
        super(s);
    }
}
